/* brand_resources.h - shared branding resources. */
#ifndef FF_BRAND_RESOURCES_H
#define FF_BRAND_RESOURCES_H
#define IDR_BRAND_PNG   201
#define IDR_FONT_SPACE  202
#define IDR_FONT_INTER  203
#endif
