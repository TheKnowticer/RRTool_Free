FELONIOUS FUNNERY - ROB RUN (PUBLIC BUILD)

1. Put FFLoader.exe and RobRunAIO.exe in the same folder.
2. Run FFLoader.exe as administrator.
3. Press LAUNCH.

No license key is required in this build.

Requirements:
- Windows 10 or 11, 64-bit
- Administrator rights (driver + overlay)
- WebView2 Runtime (included with Windows 11)
- Rob Run installed through Steam

Optional: edit RobRunAIO.ini for menu delay / attach timeout / masquerade.
